<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Customer;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CustomerController extends Controller
{
    public function store(Request $request)
    {
        $validator = Validator::make( $request->all(), [
            'name' => 'required|min:3|max:191',
            'email' => 'required|email|max:191', 
            'address' => 'required|max:191',
            'mobile' => 'required|min:10|max:10',
        ]);
        if($validator->fails())
        {
            return response()->json([
                'status'=>422,
                'message'=>$validator->messages()
            ], 422);
        }
        else{
            $customer = new Customer;
            $customer->name = $request->name;
            $customer->email = $request->email;
            $customer->address = $request->address;
            $customer->mobile = $request->mobile;
            $customer->save();

            return response()->json([
                'status'=>200,
                'message'=>'Customer created Successfully'
            ],200);
        }
    }
}
